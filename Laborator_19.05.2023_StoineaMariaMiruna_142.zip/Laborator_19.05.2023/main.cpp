#include <iostream>

using namespace std;

struct nod{
    int info;
    nod * st, * dr;
};

void Insert(nod* &rad, int x)
{
    if(rad!=NULL)
    {
        if(rad->info==x)
            return;
        else
            if(rad->info>x)
                Insert(rad->st,x);
            else
                Insert(rad->dr,x);
    }
    else
    {
        rad=new nod;
        rad->info=x;
        rad->st=NULL;
        rad->dr=NULL;
    }
}

void RSD(nod *rad)
{
    if(rad!= NULL)
    {
		cout <<rad->info<< " ";
		RSD(rad->st);
		RSD(rad->dr);
	}
}

void SRD(nod *rad)
{
    if(rad!= NULL)
    {
		SRD(rad->st);
		cout <<rad->info<< " ";
		SRD(rad->dr);
	}
}

void SDR(nod * rad)
{
    if(rad!= NULL)
    {
		SDR(rad->st);
		SDR(rad->dr);
		cout <<rad->info<< " ";
	}
}

nod* Find(nod* rad, int x)
{
    if(rad==NULL)
        return NULL;
    if(rad->info==x)
        return rad;
    if(rad->info>x)
        return Find(rad->st, x);
    else
        return Find(rad->dr, x);
}

void Caz_particular(nod* &p, nod* &rad)
{
    if(p->dr)
        Caz_particular(p->dr, rad);
    else
    {
        rad->info=p->info;
        nod* aux= p;
        p=p->st;
        delete aux;
    }
}

void Delete(nod* &rad, int x)
{
    if(rad!= NULL)
    {
        if(rad->info==x)
        {
            if(rad->st==NULL &&rad->dr==NULL)
            {
                delete rad;
                rad=NULL;
            }
            else
                if(rad->dr==NULL)
                {
                    nod* aux=rad;
                    rad=rad->st;
                    delete aux;
                }
                else
                    if(rad->st==NULL)
                    {
                        nod* aux=rad;
                        rad=rad->dr;
                        delete aux;
                    }
                    else
                        Caz_particular(rad->st,rad);
        }
        else
            if(rad->info>x)
                Delete(rad->st, x);
            else
                Delete(rad->dr, x);
    }
    else
        return;
}

int Minim(nod* rad) {
    if (rad==NULL) {
        return -1;
    }

    if (rad->st==NULL) {
        return rad->info;
    }

    return Minim(rad->st);
}

int main()
{
    nod* rad=NULL;
    Insert(rad,8);
    Insert(rad,12);
    Insert(rad,4);
    Insert(rad,1);
    Insert(rad,5);
    Insert(rad,2);
    Insert(rad,10);
    Insert(rad,20);
    Insert(rad,16);

    cout<<"Arborele creat este: \n";
    cout<<"\n-Afisat in ordine: "; SRD(rad);
    cout<<"\n-Afisat in pre-ordine: "; RSD(rad);
    cout<<"\n-Afisat in post-ordine: "; SDR(rad);

    if(Minim(rad)!=-1)
        cout<<"\nMinimul acestuia este  "<<Minim(rad);
    else
        cout<<"\nArborele este gol, deci nu are minim";

    nod* p=Find(rad,4);
    if(p!=NULL)
        cout<<"\nNodul cu valoarea 4 se afla in arbore";
    else
        cout<<"\nNodul cu valoarea 4 nu se afla in arbore";

    Delete(rad, 4);
    cout<<"\nNodul cu valoarea 4 a fost sters cu succes\n";

    SRD(rad);
    return 0;
}
