#include <iostream>

using namespace std;
struct nod{
  int info;
  nod * urm;
};
void af(nod *prim)
{
    if(prim==NULL)
        cout<<"Lista este vida";
    else if(prim->urm==NULL)
        cout<<prim->info;
    else
    {
        nod * t=prim;
        while(t!=NULL)
        {
            cout<<t->info<<" ";
            t=t->urm;
        }
    }
}
void adi(nod * & prim , int x)
{
  nod * t = new nod;
  t -> info = x;
  t -> urm = prim;
  prim = t;
}
void inversare(nod* &prim)
{
    nod* prev=NULL;
    nod* curent=prim;
    nod* next= NULL;
    while(curent!=NULL)
    {
        next=curent->urm;
        curent->urm=prev;
        prev=curent;
        curent=next;
    }
    prim=prev;
}
void Sol(nod *prim)
{
    int i,n,x;
    cout<<"Dati numarul de numele de citit"<<"\n";
    cin>>n; cout<<"Dati numerele in ordine inversa fata de cum vreti sa fie in lista (deoarece se foloseste insertia de inceput)"<<"\n";
    for(i=1; i<=n; i++)
    {
        cin>>x;
        adi(prim,x);
    }
    cout<<"Lista data este: "; af(prim); cout<<"\n";
    inversare(prim);
    cout<<"Lista inversata este: "; af(prim);
}
int main()
{
    nod *head=NULL;
    Sol(head);
    return 0;
}
