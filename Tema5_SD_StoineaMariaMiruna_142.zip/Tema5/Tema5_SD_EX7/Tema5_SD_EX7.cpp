#include <iostream>

using namespace std;
struct nod{
  int info;
  nod * urm;
};
nod* ultimulElement(nod* prim) {
  if (prim == NULL) {
    return NULL;
  }
  nod* curent = prim;
  while (curent->urm != NULL) {
    curent = curent->urm;
  }
  return curent;
}
void adf(nod * & ultim, nod * &prim, int x)
{
  nod * t = new nod;
  t->info = x;
  t->urm=NULL;

  if(ultim!=NULL)
    {ultim->urm = t;
     ultim=t;}
  else
      {ultim=t;
       prim=t;}
}
void af(nod *prim)
{
    if(prim==NULL)
        cout<<"Lista este vida";
    else if(prim->urm==NULL)
        cout<<prim->info;
    else
    {
        nod * t=prim;
        while(t!=NULL)
        {
            cout<<t->info;
            t=t->urm;
        }
    }
}
void adi(nod * & prim , int x)
{
  nod * t = new nod;
  t -> info = x;
  t -> urm = prim;
  prim = t;
}
void inversare(nod* &prim)
{
    nod* prev=NULL;
    nod* curent=prim;
    nod* next= NULL;
    while(curent!=NULL)
    {
        next=curent->urm;
        curent->urm=prev;
        prev=curent;
        curent=next;
    }
    prim=prev;
}
nod* Produs_lista_cifra(nod *prim, int nr)
{
    nod *produs=NULL;
    if(nr==0)
    {
        adi(produs,0);
        return produs;
    }
    nod *p=prim;
    nod *ultim;
    int s,cif,rest=0;
    while(p!=NULL)
    {
        s=(p->info)*nr+rest;
        cif=s%10;
        ultim=ultimulElement(produs);
        adf(ultim,produs,cif);
        rest=s/10;
        p=p->urm;
    }
    if(rest!=0)
    {
        ultim=ultimulElement(produs);
        adf(ultim,produs,rest);
    }
    return produs;
}
nod* Suma(nod *prim1, nod* prim2)
{
    nod* ultim;
    nod* p1=prim1;
    nod* p2=prim2;
    nod* suma=NULL;
    int rest=0, cif,s;
    while(p1!=NULL&&p2!=NULL)
    {
        s=p1->info+p2->info+rest;
        cif=s%10;
        ultim=ultimulElement(suma);
        adf(ultim,suma,cif);
        rest=s/10;
        p1=p1->urm;
        p2=p2->urm;
    }
    while(p1!=NULL)
    {
        s=p1->info+rest;
        cif=s%10;
        ultim=ultimulElement(suma);
        adf(ultim,suma,cif);
        rest=s/10;
        p1=p1->urm;
    }
        while(p2!=NULL)
    {
        s=p2->info+rest;
        cif=s%10;
        ultim=ultimulElement(suma);
        adf(ultim,suma,cif);
        rest=s/10;
        p2=p2->urm;
    }
    if(rest!=0)
        {
            ultim=ultimulElement(suma);
            adf(ultim,suma,rest);
        }
    return suma;
}
nod* Produs_intre_liste(nod* prim1, nod* prim2)
{
    nod *p=prim1;
    nod *produs=NULL;
    nod *prod=NULL;
    int ct=0;
    while(p!=NULL)
    {
        prod=Produs_lista_cifra(prim2,p->info);
        for(int i=1; i<=ct; i++)
            adi(prod,0);
        if(produs==NULL)
            produs=prod;
        else
            produs=Suma(produs,prod);
        p=p->urm;
        ct++;
    }
    return produs;
}
void Sol()
{
    nod* prim1=NULL;
    nod* prim2=NULL;
    int n, i,x;
    cout<<"Dati numarul de cifre al primului numar"<<"\n";
    cin>>n; cout<<"Dati cifrele in ordine, asa cum apar in primul numar"<<"\n";
    for(i=1; i<=n; i++)
    {
        cin>>x;
        adi(prim1,x);
    }
    cout<<"Dati numarul de cifre din cel de-al doilea numar"<<"\n";
    cin>>n; cout<<"Dati cifrele in ordine, asa cum apar in al doilea numar"<<"\n";
    for(i=1; i<=n; i++)
    {
        cin>>x;
        adi(prim2,x);
    }
    nod *P=Produs_intre_liste(prim1,prim2);
    inversare(P);
    af(P);
}
int main()
{
    Sol();
    return 0;
}
