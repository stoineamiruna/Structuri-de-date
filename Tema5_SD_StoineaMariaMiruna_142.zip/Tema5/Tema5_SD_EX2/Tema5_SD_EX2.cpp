#include <iostream>

using namespace std;
struct nod{
  int info;
  nod * urm;
};
void af(nod *prim)
{
    if(prim==NULL)
        cout<<"Lista este vida";
    else if(prim->urm==NULL)
        cout<<prim->info;
    else
    {
        nod * t=prim;
        while(t!=NULL)
        {
            cout<<t->info<<" ";
            t=t->urm;
        }
    }
}

void ip(nod * &prim, int poz, int val)
{
    nod *p=prim;
    if(p==NULL)
        if(poz==1)
        {
            prim->info==val;
            prim->urm=NULL;
        }
        else
            cout<<"Nu este posibil";
    else
    {
        int ct=0,info1,info2;
        bool ok=0;
        nod *t=prim;
        nod *cop1=new nod;
        nod *cop2=new nod;
        while(t!=NULL&&ok==0)
        {
            ct++;
            info1=t->info;
            cop1=t;
            if(ct==poz)
            {
                ok=1;
                cop2=t;
                nod* p=t->urm;
                while(p!=NULL)
                {
                    cop2=p;
                    info2=p->info;
                    p->info=info1;
                    info1=info2;
                    p=p->urm;
                }
                nod *w=new nod;
                w->info=info1;
                w->urm=NULL;
                cop2->urm=w;

                t->info=val;
                if(ct==1) prim=w;
            }
            t=t->urm;
        }
        if(ct+1==poz&&ok==0)
        {
            nod*w=new nod;
            w->info=val;
            w->urm=NULL;
            cop1->urm=w;

        }
    }
}
void adf(nod * & ultim, nod * &prim, int x)
{
  nod * t = new nod;
  t->info = x;
  t->urm=NULL;

  if(ultim!=NULL)
    {ultim->urm = t;
     ultim=t;}
  else
      {ultim=t;
       prim=t;}
}
nod* ultimulElement(nod* prim) {
  if (prim == NULL) {
    return NULL;
  }
  nod* curent = prim;
  while (curent->urm != NULL) {
    curent = curent->urm;
  }
  return curent;
}
void adi(nod * & prim , int x)
{
  nod * t = new nod;
  t -> info = x;
  t -> urm = prim;
  prim = t;
}

void Sol(nod *prim)
{
    int n, i,x;
    cout<<"Dati numarul de numele de citit"<<"\n";
    cin>>n; cout<<"Dati numerele"<<"\n";
    for(i=1; i<=n; i++)
    {
        cin>>x;
        if(i==1) adi(prim,x);
        else
        {
            nod *p=prim;
            if(x<=prim->info)
                adi(prim,x);
            else
            {
                int ct=0,poz=0;
                while(p->urm!=NULL&&poz==0)
                {
                    ct++;
                    if(p->info<=x&&p->urm->info>=x)
                        poz=ct+1;
                    p=p->urm;
                }
                if(poz!=0)
                    ip(prim,poz,x);
                else
                {
                    nod *ultim=ultimulElement(prim);
                    adf(ultim,prim,x);
                }
            }
        }

    }
    af(prim);
}
int main()
{
    nod *head=NULL;
    Sol(head);
    return 0;
}
