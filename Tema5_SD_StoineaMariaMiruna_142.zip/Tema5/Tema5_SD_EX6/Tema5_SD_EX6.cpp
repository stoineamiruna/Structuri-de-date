#include <iostream>

using namespace std;
struct nod{
  int info;
  nod * urm;
};
nod* ultimulElement(nod* prim) {
  if (prim == NULL) {
    return NULL;
  }
  nod* curent = prim;
  while (curent->urm != NULL) {
    curent = curent->urm;
  }
  return curent;
}
void adf(nod * & ultim, nod * &prim, int x)
{
  nod * t = new nod;
  t->info = x;
  t->urm=NULL;

  if(ultim!=NULL)
    {ultim->urm = t;
     ultim=t;}
  else
      {ultim=t;
       prim=t;}
}
void af(nod *prim)
{
    if(prim==NULL)
        cout<<"Lista este vida";
    else if(prim->urm==NULL)
        cout<<prim->info;
    else
    {
        nod * t=prim;
        while(t!=NULL)
        {
            cout<<t->info;
            t=t->urm;
        }
    }
}
void adi(nod * & prim , int x)
{
  nod * t = new nod;
  t -> info = x;
  t -> urm = prim;
  prim = t;
}
void inversare(nod* &prim)
{
    nod* prev=NULL;
    nod* curent=prim;
    nod* next= NULL;
    while(curent!=NULL)
    {
        next=curent->urm;
        curent->urm=prev;
        prev=curent;
        curent=next;
    }
    prim=prev;
}
nod* Produs(nod *prim, int nr)
{
    nod *produs=NULL;
    if(nr==0)
    {
        adi(produs,0);
        return produs;
    }
    nod *p=prim;
    nod *ultim;
    int s,cif,rest=0;
    while(p!=NULL)
    {
        s=(p->info)*nr+rest;
        cif=s%10;
        ultim=ultimulElement(produs);
        adf(ultim,produs,cif);
        rest=s/10;
        p=p->urm;
    }
    if(rest!=0)
    {
        ultim=ultimulElement(produs);
        adf(ultim,produs,rest);
    }
    return produs;
}
void Sol()
{
    nod* prim=NULL;
    int n, i,x,nr;
    cout<<"Dati numarul de cifre al primului numar"<<"\n";
    cin>>n; cout<<"Dati cifrele in ordine, asa cum apar in primul numar"<<"\n";
    for(i=1; i<=n; i++)
    {
        cin>>x;
        adi(prim,x);
    }
    cout<<"Dati al doilea numar"<<"\n";
    cin>>nr;
    nod *P=Produs(prim,nr);
    inversare(P);
    af(P);
}
int main()
{
    Sol();
    return 0;
}
