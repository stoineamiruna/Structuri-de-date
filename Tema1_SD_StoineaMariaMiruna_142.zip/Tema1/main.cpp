#include <iostream>
#define N 1010
using namespace std;
void BubbleSort(int n, int a[N]){
    bool ok=0;
    int i,aux;
    while(ok==0)
    {
        ok=1;
        for(i=1; i<n; i++)
            if(a[i]>a[i+1])
        {
            ok=0;
            aux=a[i]; a[i]=a[i+1]; a[i+1]=aux;}
    }
}
void InsertionSort(int n, int a[]) {
    for (int i = 2; i <= n; i++) {
        int j, aux = a[i];
        for (j = i; j > 1 && a[j - 1] > aux; j--)
            a[j] = a[j - 1];
            a[j] = aux;
        }
}
void SelectionSort(int n, int a[N]){
    for(int i = 1 ; i < n ; i ++)
    {
        int poz = i;
        for(int j = i + 1 ; j <= n ; j ++)
            if(a[j] < a[poz])
                poz= j;
        int aux = a[i];
        a[i] = a[poz];
        a[poz] = aux;
    }
}
int CautareSecventiala(int n, int a[N], int x) {
    for (int i=1; i <=n; i++) {
        if (a[i]==x) {
            return i;
        }
    }
    return -1;  // Elementul nu a fost găsit în șir
}
int CautareBinara(int n, int a[N], int x) {
    int st,dr,poz,mij;
    st=1;
    dr=n;
    poz=n+1;
    while(st<=dr)
    {
        mij=(st+dr)/2;
        if(a[mij]>=x)
        {
            poz=mij;
            dr=mij-1;
        }
        else
            st=mij+1;
    }
    if(a[poz]==x)
        return poz;
    else return -1;

}
void Afiseaza(int n, int a[N]){
    cout<<"\n";
    for(int i=1; i<=n; i++)
        cout<<a[i]<<" ";
}
int main()
{
    int a[N],n;
    cin>>n;
    for(int i=1; i<=n; i++)
        cin>>a[i];
    BubbleSort(n,a);
    Afiseaza(n,a);
    InsertionSort(n,a);
    Afiseaza(n,a);
    SelectionSort(n,a);
    Afiseaza(n,a);

    int x;
    cout<<"\nDati elementul cautat "; cin>>x;
    if(CautareSecventiala(n,a,x)==-1)
        cout<<"\nElementul nu s-a gasit in vector\n";
    else
        cout<<"\nPozitia sa in vector este "<<CautareSecventiala(n,a,x)<<"\n";

    if(CautareBinara(n,a,x)==-1)
        cout<<"\nElementul nu s-a gasit in vector\n";
    else
        cout<<"\nPozitia sa in vector este "<<CautareBinara(n,a,x)<<"\n";
    return 0;
}
