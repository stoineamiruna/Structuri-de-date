#include <iostream>
using namespace std;

const int dim_max = 100; // dimensiunea maxima a unei stive sau/si a unei cozi

class Stiva
{
    private:
        int varf;
        int v[dim_max]; // vector pentru stocarea elementelor stivei
    public:
        Stiva()
        {
            varf=-1; // varful=-1 => stiva este goala
        }
        bool empty()
        {
            return varf==-1;
        }
        void push(int x)
        {
            if (varf==dim_max-1)
                cout<<"Stiva este plina! Nu se mai poate adauga niciun element."<<"\n";
            else
                {
                    varf++;
                    v[varf]=x;
                }
        }
        void pop()
        {
            if (empty())
                cout<<"Stiva este goala! Nu se poate elimina niciun element."<<"\n";
            else
                varf--;
        }
        int peek()
        {
            if (empty())
            {
                cout<<"Stiva este goala! Nu putem afisa niciun element."<<"\n";
                return -1; // eroare
            }
            else
                return v[varf];
        }
        void show()
        {
            if (empty())
                cout<<"Stiva este goala! Nu se poate afisa niciun element."<<"\n";
            else
                {
                    cout<<"Elementele stivei sunt: ";
                    for (int i=0; i<=varf; i++)
                        cout<<v[i]<<" ";
                    cout<<"\n";
                }
        }
};
class Coada
{
    private:
        int st,dr;
        int v[dim_max]; // vector pentru stocarea elementelor stivei
    public:
        Coada()
        {
            st=1;
            dr=0;
        }
        bool empty()
        {
            return st>dr;
        }
        void push(int x)
        {
            if (dr==dim_max-1)
                cout<<"Coada este plina! Nu se mai poate adauga niciun element."<<"\n";
            else
                {
                    dr++;
                    v[dr]=x;
                }
        }
        void pop()
        {
            if (empty())
                cout<<"Coada este goala! Nu se poate elimina niciun element."<<"\n";
            else
                st++;
        }
        int peek()
        {
            if (empty())
            {
                cout<<"Coada este goala! Nu putem afisa niciun element."<<"\n";
                return -1; // eroare
            }
            else
                return v[st];
        }
        void show()
        {
            if (empty())
                cout<<"Coada este goala! Nu se poate afisa niciun element."<<"\n";
            else
                {
                    cout<<"Elementele cozii sunt: ";
                    for (int i=st; i<=dr; i++)
                        cout<<v[i]<<" ";
                    cout<<"\n";
                }
        }
};
bool verificaParanteze(int n, char sir[1000])
{
    Stiva stiva;
    for (int i=0; i<n; i++)
    {
        char c=sir[i];
        if(c=='(')
            stiva.push(c);
        else if(c==')')
        {
            if (stiva.empty())
                return 0;

            stiva.pop();
        }
    }
    return stiva.empty();
}
int main() {
    Stiva s;

    s.push(1);
    s.push(2);
    s.push(3);
    s.show();

    s.pop();
    cout<<s.peek()<<"\n";

    s.pop();
    s.pop();
    s.pop();

    cout<<s.peek()<<"\n";


    Coada c;

    c.push(1);
    c.push(2);
    c.push(3);
    c.show();

    c.pop();
    cout<<c.peek()<<"\n";

    c.pop();
    c.pop();
    c.pop();

    cout<<c.peek()<<"\n";


    //Pentru Problema parantezelor
    char sir[1000];
    int n;
    cin>>n; cin>>sir;
    if(verificaParanteze(n,sir))
        cout<<"\nParantezele sunt inchise corect!";
    else
        cout<<"\nParantezele nu sunt inchise corect!";
    return 0;
}
