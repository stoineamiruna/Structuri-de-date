#include <iostream>

using namespace std;
struct nod{
    int info;
    nod * st, * dr;
};

void Insert(nod* &rad, int x)
{
    if(rad!=NULL)
    {
        if(rad->info==x)
            return;
        else
            if(rad->info>x)
                Insert(rad->st,x);
            else
                Insert(rad->dr,x);
    }
    else
    {
        rad=new nod;
        rad->info=x;
        rad->st=NULL;
        rad->dr=NULL;
    }
}

void RSD(nod *rad)
{
    if(rad!= NULL)
    {
		cout <<rad->info<< " ";
		RSD(rad->st);
		RSD(rad->dr);
	}
}

void SRD(nod *rad)
{
    if(rad!= NULL)
    {
		SRD(rad->st);
		cout <<rad->info<< " ";
		SRD(rad->dr);
	}
}

void SDR(nod * rad)
{
    if(rad!= NULL)
    {
		SDR(rad->st);
		SDR(rad->dr);
		cout <<rad->info<< " ";
	}
}
void Parcurgere_Nivel(nod* rad, int nivel, int k, bool &ok){
    if(rad!= NULL)
    {
		Parcurgere_Nivel(rad->st, nivel+1, k, ok);
		if(nivel==k)
            {cout <<rad->info<< " "; ok=1;}
		Parcurgere_Nivel(rad->dr, nivel+1, k, ok);
	}
}
void NivelK(nod *rad, int k){
    bool ok=0;
    cout<<"\nNodurile e pe nivelul "<<k<<" sunt:\n";
    Parcurgere_Nivel(rad, 0, k, ok);
    if(ok==0)
        cout<<" Nu exista noduri pe acest nivel!";
}
int main()
{
    nod *rad=NULL;
    Insert(rad,8);
    Insert(rad,12);
    Insert(rad,4);
    Insert(rad,1);
    Insert(rad,5);
    Insert(rad,2);
    Insert(rad,10);
    Insert(rad,20);
    Insert(rad,16);
    RSD(rad);
    NivelK(rad,2);



    return 0;
}
