#include <iostream>

using namespace std;
struct nod{
  int info;
  nod * urm;
};
nod * prim = NULL;

void adi(nod * & prim , int x)
{
  nod * t = new nod;
  t -> info = x;
  t -> urm = prim;
  prim = t;
}
void adf(nod * & ultim, nod * &prim, int x)
{
  nod * t = new nod;
  t->info = x;
  t->urm=NULL;

  if(ultim!=NULL)
    {ultim->urm = t;
     ultim=t;}
  else
      {ultim=t;
       prim=t;}
}
void af(nod *prim)
{
    if(prim==NULL)
        cout<<"Lista este vida";
    else if(prim->urm==NULL)
        cout<<prim->info;
    else
    {
        nod * t=prim;
        while(t!=NULL)
        {
            cout<<t->info<<" ";
            t=t->urm;
        }
    }
}
int cv(nod * prim, int x)
{
    int ct;
    if(prim==NULL)
        return -1;
    else
    {
        ct=0;
        nod * t=prim;
        while(t!=NULL)
        {
            ct++;
            if(t->info==x)
                return ct;
            t=t->urm;
        }
    }
    return -1;
}
int cp(nod * prim, int poz)
{
    int ct;
    if(prim==NULL)
        return -1;
    else
    {
        ct=0;
        nod * t=prim;
        while(t!=NULL)
        {
            ct+=1;
            if(ct==poz)
                return t->info;
            t=t->urm;
        }
    }
    return -1;
}
void iv(nod *prim, int x, int val)
{
    if(prim==NULL)
        cout<<"Lista este vida";
    else
    {
        nod *t=prim;
        bool ok=0;
        while(t!=NULL && ok==0)
        {
            if(t->info==x &&t->urm==NULL)
            {
                nod *p=new nod;
                p->urm=NULL;
                p->info=val;
                t->urm=p;
                ok=1;
            }
            else if(t->info==x)
            {
                ok=1;
                nod *p=new nod;
                p->info=val;

                nod *q=t;
                int info1,info2;
                q=q->urm;
                info1=q->info;
                while(q->urm!=NULL)
                {
                    info2=q->urm->info;
                    q->urm->info=info1;
                    info1=info2;
                    q=q->urm;
                }
                nod *w=new nod;
                w->info=info1;
                w->urm=NULL;
                q->urm=w;

                t->urm->info=val;
            }
            else
                t=t->urm;
        }

    }
}
void ip(nod * &prim, int poz, int val)
{
    nod *p=prim;
    if(p==NULL)
        if(poz==1)
        {
            prim->info==val;
            prim->urm=NULL;
        }
        else
            cout<<"Nu este posibil";
    else
    {
        int ct=0,info1,info2;
        bool ok=0;
        nod *t=prim;
        nod *cop1=new nod;
        nod *cop2=new nod;
        while(t!=NULL&&ok==0)
        {
            ct++;
            info1=t->info;
            cop1=t;
            if(ct==poz)
            {
                ok=1;
                cop2=t;
                nod* p=t->urm;
                while(p!=NULL)
                {
                    cop2=p;
                    info2=p->info;
                    p->info=info1;
                    info1=info2;
                    p=p->urm;
                }
                nod *w=new nod;
                w->info=info1;
                w->urm=NULL;
                cop2->urm=w;

                t->info=val;
                if(ct==1) prim=w;
            }
            t=t->urm;
        }
        if(ct+1==poz&&ok==0)
        {
            nod*w=new nod;
            w->info=val;
            w->urm=NULL;
            cop1->urm=w;

        }
    }
}

void sv(nod * &prim, int val)
{
    if(prim==NULL)
        cout<<"Lista este vida";
    else if(prim->urm==NULL && prim->info==val)
        prim=NULL;
    else
    {
        nod *p=prim;
        nod *cop2=prim;
        while(p!=NULL)
        {
            if(p->info==val)
                if(p->urm==NULL) cop2->urm=NULL;
                else
                {
                    nod *t=p;
                    nod *cop=p;
                    while(t->urm!=NULL)
                    {
                        t->info=t->urm->info;
                        cop=t;
                        t=t->urm;
                    }
                    cop->urm=NULL;
                }
            cop2=p;
            p=p->urm;
        }
    }
}
void sp(nod * &prim, int poz)
{
    if(prim==NULL)
        cout<<"Lista este vida";
    else if(prim->urm==NULL && poz==1)
        prim=NULL;
    else
    {
        nod *p=prim;
        nod *cop2=prim;
        int ct=0;
        while(p!=NULL)
        {
            ct++;
            if(ct==poz)
                if(p->urm==NULL) cop2->urm=NULL;
                else
                {
                    nod *t=p;
                    nod *cop=p;
                    while(t->urm!=NULL)
                    {
                        t->info=t->urm->info;
                        cop=t;
                        t=t->urm;
                    }
                    cop->urm=NULL;
                }
            cop2=p;
            p=p->urm;
        }
    }
}

nod* ultimulElement(nod* prim) {
  if (prim == NULL) {
    return NULL;
  }
  nod* curent = prim;
  while (curent->urm != NULL) {
    curent = curent->urm;
  }
  return curent;
}
int main()
{
    int List[100];
    nod *head = NULL;
    af(head);
    adi(head,1);
    adi(head,2);
    adi(head,3);
    cout<<"\n";
    af(head);
    nod *ultim=ultimulElement(head);
    adf(ultim,head,4);
    cout<<"\n";
    af(head);
    cout<<"\n";
    cout<<cv(head,-5);
    cout<<"\n";
    cout<<cv(head,1);
    cout<<"\n";
    cout<<cp(head,5);
    cout<<"\n";
    cout<<cp(head,3);
    cout<<"\n";

    sp(head,1);
    af(head);
    cout<<"\n";
    sp(head,1);
    af(head);
    cout<<"\n";
    sv(head,4);
    af(head);
    cout<<"\n";
    ultim=ultimulElement(head);
    adf(ultim,prim,5);
    af(head);
    cout<<"\n";
    sv(head,1);
    sp(head,1);
    af(head);
    cout<<"\n";
    ultim=ultimulElement(head);
    adf(ultim,head,8);
    af(head);
    return 0;
}
