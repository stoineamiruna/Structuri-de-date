#include <iostream>
#define N 1000
using namespace std;

int main()
{
    int n,v[N],k,i,j;
    cin>>n;
    for(i=1; i<=n; i++)
        cin>>v[i];
    cin>>k;
    for(i=1; i<=n; i++)
        if(v[i]==k)
    {
        for(j=i; j<=n; j++)
            v[j]=v[j+1];
        n--;
        i--;
    }
    for(i=1; i<=n; i++)
        cout<<v[i]<<" ";
    return 0;
}
