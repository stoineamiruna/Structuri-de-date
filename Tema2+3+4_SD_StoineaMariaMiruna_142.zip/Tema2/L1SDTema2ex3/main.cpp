#include <iostream>
#define N 1000
using namespace std;

int main()
{
    int n,i,v[N],t, w[N],j,k;
    cin>>n;
    for(i=1; i<=n; i++)
        cin>>v[i];
    cin>>t;
    for(i=1; i<=t; i++)
        cin>>w[i];
    cin>>k;
    bool ok=0;
    for(i=1; i<=n&&ok==0; i++)
        if(v[i]==k)
        {
            ok=1;
            int poz=i+1;
            for(j=poz; j<=n; j++)
                v[j+t]=v[j];
            for(j=poz; j<poz+t; j++)
                v[j]=w[j-poz+1];
            /// 1 2 3 11 12 13 14 4 5  11 12 13 14   4
            /// 5   1 2 3 4 5   3   11 12 13   3
            n=n+t;
        }
    for(i=1; i<=n; i++)
        cout<<v[i]<<" ";
    return 0;
}
