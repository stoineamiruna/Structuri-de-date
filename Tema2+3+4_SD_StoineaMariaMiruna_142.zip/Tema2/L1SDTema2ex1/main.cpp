#include <iostream>
#define N 1000
using namespace std;

int main()
{
    int n, v[N],i,vmin,vmax;
    cin>>n;
    for(i=1; i<=n; i++)
        cin>>v[i];
    if(v[1]>v[n])
        {vmax=v[1]; vmin=v[n];}
    else
        {vmax=v[n]; vmin=v[1];}
    for(i=2; i<=(n+1)/2; i++)
        if(v[i]>v[n+1-i])
        {
            if(v[i]>vmax) vmax=v[i];
            if(v[n+1-i]<vmin) vmin=v[n+1-i];
        }
        else
        {
            if(v[n+1-i]>vmax) vmax=v[n+1-i];
            if(v[i]<vmin) vmin=v[i];
        }
    cout<<vmin<<" "<<vmax;
    return 0;
}
