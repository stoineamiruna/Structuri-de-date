#include <iostream>
#define N 1000
using namespace std;

int main()
{
    int n, v[N], x,i;
    cin>>n;
    for(i=1; i<=n; i++)
        cin>>v[i];
    x=v[1];
    for(i=2; i<=n; i++)
        x=x&v[i];
    cout<<x;
    return 0;
}
