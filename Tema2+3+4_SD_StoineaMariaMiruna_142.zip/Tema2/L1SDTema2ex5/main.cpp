#include <iostream>
#define N 1000
using namespace std;

int main()
{
    int n, a[N],i,t,suma=0,p=0;
    cin>>n;
    for(i=0; i<=n; i++)
        cin>>a[i];
    cin>>t;
    for(i=0; i<=n; i++)
    {
        if(i==0)
            {suma=a[0]; p=t;}
        else
            {suma=suma+p*a[i];
             p*=t;
            }

    }
    cout<<suma;
    return 0;
}
