#include <iostream>
#define N 1000
using namespace std;

int main()
{
    int n,a[N],i,j,m,b[N],Prod[N],gradProd;
    cin>>n;
    for(i=0; i<=n; i++)
        cin>>a[i];
    cin>>m;
    for(i=0; i<=m; i++)
        cin>>b[i];
    gradProd=n+m;
    for(i=0; i<=gradProd; i++)
        Prod[i]=0;
    for(i=0; i<=n; i++)
        for(j=0; j<=m; j++)
            Prod[i+j]=Prod[i+j]+a[i]*b[j];
    for(i=0; i<=gradProd; i++)
        cout<<Prod[i]<<" ";
    return 0;
}
