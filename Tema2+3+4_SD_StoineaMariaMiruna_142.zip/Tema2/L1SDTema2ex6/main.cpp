#include <iostream>
#define N 1000
using namespace std;

int main()
{
    int n,a[N],i,m,b[N],S[N],gradS;
    cin>>n;
    for(i=0; i<=n; i++)
        cin>>a[i];
    cin>>m;
    for(i=0; i<=m; i++)
        cin>>b[i];
    if(m>n)
        {
            gradS=m;
            for(i=n+1; i<=m; i++)
                a[i]=0;
        }
    else if(m<n)
         {
            gradS=n;
            for(i=m+1; i<=n; i++)
                b[i]=0;
        }

    for(i=0; i<=gradS; i++)
        S[i]=a[i]+b[i];

    cout<<gradS<<"\n";
    for(i=0; i<=gradS; i++)
        cout<<S[i]<<" ";
    return 0;
}
